<?php
include("inc/header.php");
include('inc/vt.php');
include("hakkimizda.php");
include("servisler.php");
include("portfolyo.php");
include("katalog.php");
include("takim.php");
include("ortaklar.php");
include("iletisim.php");
include("inc/footer.php");
?>





